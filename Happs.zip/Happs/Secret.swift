//
//  Secret.swift
//  Happs
//
//  Created by Rafa Abes on 10/17/26.
//
enum Secrets {
    /// Free key from developer.ticketmaster.com (My Apps > Consumer Key).
    static let ticketmasterAPIKey = "k2VNtwRbXrnIYPvaN58GBspwffVV0LxA"
    static let supabaseURL = "https://uajbprlagohkyfvvtqbx.supabase.co"
    static let supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVhamJwcmxhZ29oa3lmdnZ0cWJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMwNzQ2OTksImV4cCI6MjEwODY1MDY5OX0.zxH248QiXK5s_AA14pdLrWMXqG5Z9SP8sa-3W4GdeOQ"
}
